#ifndef _TETRIS_AI_H_INCLUDED_
#define _TETRIS_AI_H_INCLUDED_

#include "TetrisBoard.h"

class TetrisDecision
{
public:
	TetrisDecision( int x, int rot ) : x( x ), rot( rot ) { }

	int x;
	int rot;
};

class TetrisAI
{
public:
	TetrisAI();
	virtual ~TetrisAI();

	// �� �ϸ��� ȣ��ȴ�
	TetrisDecision Think( const TetrisBoard& tb );
};

#endif