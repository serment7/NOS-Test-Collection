#include "TetrisBoard.h"
#include <cassert>
#include <cstring>
#include <cstdio>

using namespace std;

TetrisBoard::TetrisBoard( int seed, int grayHeight, int holes ) : m_rand( seed ), m_status( STATUS_PLAYING )
{
	m_givenPieceShape = m_rand.IRandom( 1, 7 );
	m_nextPieceShape  = m_rand.IRandom( 1, 7 );

	memset( m_board, 0, sizeof( m_board ) );
	for( int y = HEIGHT - grayHeight; y < HEIGHT; ++y )
	{
		for( int x = 0; x < WIDTH; ++x )
		{
			m_board[ y ][ x ] = BLOCK_GRAY;
		}

		for( int e = 0; e < holes; ++e )
		{
			int x = m_rand.IRandom( 0, WIDTH - 1 );
			m_board[ y ][ x ] = BLOCK_EMPTY;
		}
	}
}

TetrisBoard::~TetrisBoard()
{
}

int TetrisBoard::GetGivenPieceShape() const
{
	return m_givenPieceShape;
}

int TetrisBoard::GetNextPieceShape() const
{
	return m_nextPieceShape;
}

void TetrisBoard::GetBoard( char board[ HEIGHT ][ WIDTH ] ) const
{
	assert( sizeof( board ) == sizeof( m_board ) );
	memcpy( board, m_board, sizeof( m_board ) );
}

void TetrisBoard::PrintBoard() const
{
	static const char* unit[ 3 ] = { "��", "��", "��" };

	printf( "   " );
	for( int x = 0; x < WIDTH; ++x )
	{
		printf( "%2d", x );
	}
	printf( "\n" );

	for( int y = 0; y < HEIGHT; ++y )
	{
		printf( "%2d ", y );
		for( int x = 0; x < WIDTH; ++x )
		{
			printf( "%s", unit[ m_board[ y ][ x ] ] );
		}
		printf( "\n" );
	}
	printf( "---\n" );
}

void TetrisBoard::Decide( int x, int rotation )
{
	assert( m_status == STATUS_PLAYING );
	assert( 1 <= rotation && rotation <= 4 );
	assert( x >= 0 );

	for( int y = 0; y <= HEIGHT; ++y )
	{
		if( Collides( m_givenPieceShape, x, y, rotation ) )
		{
			if( y == 0 )
			{
				m_status = STATUS_GAMEOVER;
			}
			else
			{
				PlacePiece( m_givenPieceShape, x, y - 1, rotation );
				if( IsCleared() )
				{
					m_status = STATUS_CLEARED;
				}
			}

			m_givenPieceShape = m_nextPieceShape;
			m_nextPieceShape = m_rand.IRandom( 1, 7 );
			return;
		}
	}

	assert( false );
}

TetrisBoard::Status TetrisBoard::GetStatus() const
{
	return m_status;
}

bool TetrisBoard::Collides( int shape, int x, int y, int rot ) const
{
	const TetrisPiece& b = TetrisPiece::Get( shape, rot );

	assert( x >= 0 && y >= 0 );

	for( int dy = 0; dy < 4; ++dy )
	{
		for( int dx = 0; dx < 4; ++dx )
		{
			if( b.m_matrix[ dy ][ dx ] )
			{
				if( x + dx >= WIDTH ||
					y + dy >= HEIGHT ||
					m_board[ y + dy ][ x + dx ] )
				{
					return true;
				}
			}
		}
	}
	return false;
}

void TetrisBoard::PlacePiece( int shape, int x, int y, int rot )
{
	const TetrisPiece& b = TetrisPiece::Get( shape, rot );

	assert( x >= 0 && y >= 0 );

	for( int dy = 0; dy < 4; ++dy )
	{
		for( int dx = 0; dx < 4; ++dx )
		{
			if( b.m_matrix[ dy ][ dx ] )
			{
				assert( x + dx < WIDTH &&
						y + dy < HEIGHT &&
						m_board[ y + dy ][ x + dx ] == BLOCK_EMPTY );
				m_board[ y + dy ][ x + dx ] = BLOCK_PIECE;
			}
		}
	}

	for( int y = 0; y < HEIGHT; ++y )
	{
		int numEmpty = 0;
		for( int x = 0; x < WIDTH; ++x )
		{
			numEmpty += ( m_board[ y ][ x ] == BLOCK_EMPTY ? 1 : 0 );
		}
		if( numEmpty == 0 )
		{
			if( y > 0 )
			{
				memmove( m_board[ 1 ], m_board[ 0 ], WIDTH * y );
			}
			memset( m_board[ 0 ], 0, WIDTH );
		}
	}
}

bool TetrisBoard::IsCleared() const
{
	for( int x = 0; x < WIDTH; ++x )
	{
		if( m_board[ HEIGHT - 1 ][ x ] == BLOCK_GRAY )
		{
			return false;
		}
	}
	return true;
}


// --------------------------------------------------------------------
TetrisPiece TetrisPiece::s_pieces[ 7 + 1 ][ 4 + 1 ]; // [shape][rotate]

TetrisPiece::TetrisPiece()
{
	memset( m_matrix, 0, sizeof( m_matrix ) );
}

TetrisPiece::TetrisPiece( const char* mat )
{
	assert( mat[ 17 ] == '\0' );
	for( int y = 0; y < 4; ++y )
	{
		for( int x = 0; x < 4; ++x )
		{
			char c = mat[ y * 4 + x ];
			assert( c == '#' || c == '.' );
			m_matrix[ y ][ x ] = ( c == '#' );
		}
	}
}

bool TetrisPiece::Initialize()
{
	s_pieces[1][1] = s_pieces[1][3] = TetrisPiece(
		"####"
		"...."
		"...."
		"...." );

	s_pieces[1][2] = s_pieces[1][4] = TetrisPiece(
		"#..."
		"#..."
		"#..."
		"#..." );

	s_pieces[2][1] = s_pieces[2][2] = s_pieces[2][3] = s_pieces[2][4] = TetrisPiece(
		"##.."
		"##.."
		"...."
		"...." );

	s_pieces[3][1] = s_pieces[3][3] = TetrisPiece(
		"#..."
		"##.."
		".#.."
		"...." );

	s_pieces[3][2] = s_pieces[3][4] = TetrisPiece(
		".##."
		"##.."
		"...."
		"...." );

	s_pieces[4][1] = s_pieces[4][3] = TetrisPiece(
		".#.."
		"##.."
		"#..."
		"...." );

	s_pieces[4][2] = s_pieces[4][4] = TetrisPiece(
		"##.."
		".##."
		"...."
		"...." );

	s_pieces[5][1] = TetrisPiece(
		"#..."
		"##.."
		"#..."
		"...." );

	s_pieces[5][2] = TetrisPiece(
		".#.."
		"###."
		"...."
		"...." );

	s_pieces[5][3] = TetrisPiece(
		".#.."
		"##.."
		".#.."
		"...." );

	s_pieces[5][4] = TetrisPiece(
		"###."
		".#.."
		"...."
		"...." );

	s_pieces[6][1] = TetrisPiece(
		"#..."
		"#..."
		"##.."
		"...." );

	s_pieces[6][2] = TetrisPiece(
		"###."
		"#..."
		"...."
		"...." );

	s_pieces[6][3] = TetrisPiece(
		"##.."
		".#.."
		".#.."
		"...." );

	s_pieces[6][4] = TetrisPiece(
		"..#."
		"###."
		"...."
		"...." );

	s_pieces[7][1] = TetrisPiece(
		".#.."
		".#.."
		"##.."
		"...." );

	s_pieces[7][2] = TetrisPiece(
		"#..."
		"###."
		"...."
		"...." );

	s_pieces[7][3] = TetrisPiece(
		"##.."
		"#..."
		"#..."
		"...." );

	s_pieces[7][4] = TetrisPiece(
		"###."
		"..#."
		"...."
		"...." );

	return true;
}

const TetrisPiece& TetrisPiece::Get( int shape, int rotation )
{
	static bool initialized = Initialize();
	assert( 1 <= shape && shape <= 7 );
	assert( 1 <= rotation && rotation <= 4 );
	return s_pieces[ shape ][ rotation ];
}

void TetrisPiece::PrintPiece() const
{
	for( int y = 0; y < 4; ++y )
	{
		for( int x = 0; x < 4; ++x )
		{
			printf( "%s", m_matrix[ y ][ x ] ? "��" : "��" );
		}
		printf( "\n" );
	}
}

