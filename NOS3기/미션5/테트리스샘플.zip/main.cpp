#include "TetrisBoard.h"
#include "TetrisAI.h"

#include <cstdlib>
#include <cstdio>

using namespace std;

int main( int argc, char* argv[] )
{
	int seed       = ( argc > 1 ) ? atoi( argv[ 1 ] ) : 0;
	int grayHeight = ( argc > 2 ) ? atoi( argv[ 2 ] ) : 5;
	int holes      = ( argc > 3 ) ? atoi( argv[ 3 ] ) : 2;

	if( grayHeight < 1 || grayHeight > 15 )
	{
		printf( "grayHeight: out of range\n" );
		return 1;
	}

	if( holes < 1 || holes > 9 )
	{
		printf( "holes: out of range\n" );
		return 1;
	}

	TetrisBoard tb( seed, grayHeight, holes );
	tb.PrintBoard();

	int turn = 0;
	TetrisAI ai;
	while( tb.GetStatus() == TetrisBoard::STATUS_PLAYING )
	{
		TetrisDecision decision = ai.Think( tb );
		tb.Decide( decision.x, decision.rot );

		printf( "turn %d:\n", turn );
		tb.PrintBoard();

		++turn;
	}

	switch( tb.GetStatus() )
	{
	case TetrisBoard::STATUS_CLEARED:
		printf( "Cleared:%d.\n", turn );
		break;

	case TetrisBoard::STATUS_GAMEOVER:
		printf( "GAME OVER.\n" );
		break;
	}

	return 0;
};

