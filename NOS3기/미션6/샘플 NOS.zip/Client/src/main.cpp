#include "protocol.h"
#include <string>
#include <time.h>

using namespace std;

int main(void)
{
	string teamName("TheCakeIsALie");
	string ip("127.0.0.1");
	int port = 23468;
	int i=0;

	Protocol p(teamName, ip, port);

	p.handshake();

	while (true)
	{
		Board board = p.update();
		//TODO : Implement HERE
	}
	  

	return 0;
}

