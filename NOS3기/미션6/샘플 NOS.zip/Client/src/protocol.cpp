#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstddef>
#include <cassert>
#include "protocol.h"

using namespace std;

void error(string err)
{
	printf("%s\n", err.data());
	exit(0);
}

Protocol::Protocol(const string& authstring, const string& ip, int port):
	authstring_(authstring), socket_(INVALID_SOCKET)
{
	if (WSAStartup(MAKEWORD(2,2), &wsadata_) != 0) {
		error("WSAStartup() failed");
	}

	socket_ = socket(AF_INET, SOCK_STREAM, 0);
	if (socket_ == INVALID_SOCKET) {
		error("socket() failed");
	}

	SOCKADDR_IN addr;
	memset(&addr, 0, sizeof addr);
	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	addr.sin_addr.s_addr = inet_addr(ip.c_str());

	if (connect(socket_, reinterpret_cast<SOCKADDR*>(&addr), sizeof addr) == -1) {
		error("connect() failed");
	}
}

Protocol::~Protocol()
{
	if (socket_ != INVALID_SOCKET) {
		closesocket(socket_);
	}
	WSACleanup();
}

void Protocol::sendline(const string& line) const
{
	int len = line.length();
	if (send(socket_, line.c_str(), len, 0) != len) {
		error("send() failed");
	}
}

vector<string> Protocol::recvline() const
{
	vector<string> strlist;
	string buf;
	printf("received msg : ");
	while (true) {
		char ch;
		int nread = recv(socket_, &ch, 1, 0);
		if (nread == 0) {
			error("connection closed");
		}
		if (nread != 1) {
			error("_recv() failed");
		}
		printf("%c", ch);
		if (ch == ' ') {
			strlist.push_back(buf);
			buf.clear();
		}
		else if (ch == '\n') {
			strlist.push_back(buf);
			break;
		}
		else
			buf.push_back(ch);
	}
	return strlist;
}

void Protocol::handshake() const
{
	sendline("join " + authstring_ + "\n");
	vector<string> reply = recvline();
	if (reply[0] != "ack") {
		error("unexpected reply \"" + reply[0] + "\"");
	}
}

void Protocol::sendMsg(const string & str) const
{
	sendline("msg " + str + "\n");
}

//turn���� update()���� ���� turn�� �״�� �־��ּ���.
void Protocol::moveSlime(int fromx, int fromy, int tox, int toy, int number, int turn) const
{
	assert(fromx < 10 && fromx >= 0);
	assert(fromy < 10 && fromy >= 0);
	assert(tox < 10 && tox >= 0);
	assert(toy < 10 && toy >= 0);

	char buf[256];
	sprintf(buf, "put %d %d %d %d %d %d\n", fromx, fromy, tox, toy, number, turn);
	sendline(buf);
}

//turn���� update()���� ���� turn�� �״�� �־��ּ���.
void Protocol::moveQSlime(int tox, int toy, int turn) const
{
	assert(tox < 10 && tox >= 0);
	assert(toy < 10 && toy >= 0);

	char buf[256];
	sprintf(buf, "qput %d %d %d\n", tox, toy, turn);
	sendline(buf);
}

const Board Protocol::update() const
{
	vector<string> reply = recvline();
	Board board;

	if(reply.size() == 1)
	{
		assert(reply[0] == "susp");
	}
	else if(reply.size() == 2)
	{
		assert(reply[0] == "end");
		exit(0);
	}
	else
	{
		int i = 0;
		assert(reply.size() == 172);
		for(int j = 0; j < 81; j++)
			board.slime[j%9][j/9] = atoi(reply[++i].data());
		for(int j = 0; j < 81; j++)
			board.territory[j%9][j/9] = atoi(reply[++i].data());
		board.turn = atoi(reply[++i].data());
		board.myQueen[0] = atoi(reply[++i].data());
		board.myQueen[1] = atoi(reply[++i].data());
		board.enemyQueen[0] = atoi(reply[++i].data());
		board.enemyQueen[1] = atoi(reply[++i].data());

		//else, mynumberslime, enemynumberslime, mypoint, enemypoint
	}

	return board;
}
