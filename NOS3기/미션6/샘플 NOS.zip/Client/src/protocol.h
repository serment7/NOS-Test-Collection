#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <string>
#include <vector>
#include <winsock2.h>

class Board
{
public:
	int slime[9][9];
	int territory[9][9];
	int turn;
	int myQueen[2];
	int enemyQueen[2];

	Board(){};
};

class Protocol
{
private:
	std::string authstring_;
	WSADATA wsadata_;
	SOCKET socket_;

	void sendline(const std::string& line) const;
	std::vector<std::string> recvline() const;

public:
	Protocol(const std::string& authstring, const std::string& ip, int port);
	~Protocol();

	// called only once, when starting
	void handshake() const;

	//send message
	void sendMsg(const std::string & str) const;
	//move slime
	//turn���� update()���� ���� turn�� �״�� �־��ּ���.
	void moveSlime(int fromx, int fromy, int tox, int toy, int number, int turn) const;
	//move queen slime
	//turn���� update()���� ���� turn�� �״�� �־��ּ���.
	void moveQSlime(int tox, int toy, int turn) const;

	const Board update() const;
};

#endif

